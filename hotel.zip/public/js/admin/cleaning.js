$(function () {


});

function asignar(item){
    //$('#cli').val(item['']);
    $("#myModal").modal('show');
}
