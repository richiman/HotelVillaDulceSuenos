<?php $__env->startSection('content'); ?>
    <br>
    <div class="container d-flex  justify-content-center" >
        <form id="form1">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" id="id" value="<?php echo e($cliente->id); ?>">
            <div style="padding-bottom: 18px;font-size : 24px;" class="text-center">Edite los datos del cliente</div>
            <div style="display: flex; padding-bottom: 18px;width : 450px;">
                <div style=" margin-left : 0; margin-right : 1%; width : 25%;">Identificador<span style="color: red;"> *</span><br/>
                    <input type="text" id="data_2"  style="width: 100%;" class="form-control" name="txtid" required="" value="<?php echo e($cliente->id); ?>" readonly="">
                </div>
                <div style=" margin-left : 0; margin-right : 1%; width : 75%;">Nombre<span style="color: red;">*</span><br/>
                </div>
            </div>
            <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Correo<span style="color: red; " > </span>
                <input type="text" id="data_5"  style="width : 450px;" class="form-control" name="txtcorreo" required="" value="<?php echo e($cliente->correo); ?>" >
            </div>
            <br>
            <div >Telefono<span style="color: red;"> *</span><br/>
                <input type="text" id="data_3"  style="width: 100%;" class="form-control" name="txttelefono" required="" value="<?php echo e($cliente->telefono); ?>">
            </div>
            <br>
            <div >Telefono<span style="color: red;"> *</span><br/>
                <input type="text" id="data_3"  style="width: 100%;" class="form-control" name="txttelefono" required="" value="<?php echo e($cliente->estado); ?>">
            </div>
        </form>
        <br>
    </div>
    <div class=" text-center">
        <input type="submit" class="btn btn-lg btn-success  center-block" id="registrar" value="Editar" >
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('/js/admin/clientes.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\battlestation\Desktop\Sistema Hotel\hotel\resources\views/editcliente.blade.php ENDPATH**/ ?>