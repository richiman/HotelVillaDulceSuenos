<section class="content-header">
    <h1>
        <?php echo e($ventana); ?>

    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li class="active"><?php echo e($name); ?></li>
    </ol>
</section>
<?php /**PATH /home/u433255739/domains/villadulcesuenos.com/public_html/hotel/resources/views/partials/navbar.blade.php ENDPATH**/ ?>