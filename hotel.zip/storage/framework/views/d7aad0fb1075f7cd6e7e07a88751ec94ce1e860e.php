<?php $__env->startSection('content'); ?>
    <br>

    <div class="container d-flex  justify-content-center" >
        <form id="form1">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" id="id" value="<?php echo e($empleado->id); ?>">
            <div style="padding-bottom: 18px;font-size : 24px;" class="text-center">Edite los datos del Usuario</div>
            <div style="display: flex; padding-bottom: 18px;width : 450px;">
                <div style=" margin-left : 0; margin-right : 1%; width : 25%;">Identificador<span style="color: red;"> *</span><br/>

                    <input type="text" id="data_2"  style="width: 100%;" class="form-control" name="txtid" required="" value="<?php echo e($empleado->id); ?>" readonly="">
                </div>
                <div style=" margin-left : 0; margin-right : 1%; width : 75%;">Nombre<span style="color: red;"> *</span><br/>

                    <input type="text" id="data_2"  style="width: 100%;" class="form-control" name="txtnombres" required="" value="<?php echo e($empleado->nombre); ?>">
                </div>

            </div>
            <div style="padding-bottom: 18px;">User<span style="color: red;"> *</span><br/>
                <input type="text" id="data_4" style="width : 450px;" class="form-control" name="txtusuario" required=""value="<?php echo e($empleado->user); ?>" >
            </div>
            <div style="padding-bottom: 18px;">Clave<span style="color: red;"> *</span><br/>
                <input type="text" id="data_5"  style="width : 450px;" class="form-control" name="txtcontra" required="" value="<?php echo e($empleado->password); ?>" >
            </div>

            <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Correo<span style="color: red; " > </span>
                <input type="text" id="data_5"  style="width : 450px;" class="form-control" name="txtcorreo" required="" value="<?php echo e($empleado->correo); ?>" >

            </div>


            <br>
            <div >Telefono<span style="color: red;"> *</span><br/>
                <input type="text" id="data_3"  style="width: 100%;" class="form-control" name="txttelefono" required="" value="<?php echo e($empleado->telefono); ?>">

            </div>
            <br>
            <div class="form-group">
                <label>Tipo</label>
                <select name="txttipo" class="form-control"  required>
                    <option value="">SELECCIONE ROL</option>
                    <?php if($empleado->tipo == 1): ?>
                        <option value="1" selected>ADMIN</option>
                        <?php else: ?>
                        <option value="1">ADMIN</option>
                    <?php endif; ?>

                    <?php if($empleado->tipo == 2): ?>
                        <option value="2" selected>RECEPCION</option>
                    <?php else: ?>
                        <option value="2">RECEPCION</option>
                    <?php endif; ?>

                    <?php if($empleado->tipo == 3): ?>
                        <option value="3" selected>TRABAJADOR</option>
                    <?php else: ?>
                        <option value="3">TRABAJADOR</option>
                    <?php endif; ?>

                </select>

            </div>

        </form>
        <br>

    </div>
    <div class=" text-center">
        <input type="submit" class="btn btn-lg btn-success  center-block" id="registrar" value="Editar" >

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('/js/admin/usuarios.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\battlestation\Desktop\Sistema Hotel\hotel\resources\views/editUser.blade.php ENDPATH**/ ?>