<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', ['ventana' => 'Reservar','name'=>'reservar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="">
        <div class="d-flex justify-content-around " >
            <form id="formReservacion">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" value="<?php echo e($id); ?>" id="idR">
                <div style="font-size : 24px;" class="text-center">Llene los datos del Hospedaje  </div>
                <div style="display: flex; padding-bottom: 18px;width : 450px;">
                    <div style=" margin-left : 0; margin-right : 1%; width : 100%;">Nombre Completo<span style="color: red;"> *</span><br/>
                        <input type="text" id="data_2"  style="width: 100%;" class="form-control"
                               name="txtnombres" required="" autocomplete="off" value="<?php echo e($reserva->nombre); ?>" readonly>
                    </div>
                </div>
                <div style="padding-bottom: 18px;">Num. Tel<span style="color: red;"> *</span><br/>
                    <input type="text" id="data_4" style="width : 450px;" class="form-control"
                           name="txtnum" required="" autocomplete="off" readonly value="<?php echo e($reserva->telefono); ?>">
                </div>
                <div style="padding-bottom: 18px;">Correo<span style="color: red;"> *</span><br/>
                    <input type="text" id="data_5"  style="width : 450px;" class="form-control" name="txtcorreo" required="" autocomplete="off"
                           placeholder="Si no cuenta con correo ingresar un guion -" value="<?php echo e($reserva->correo); ?>" readonly>
                </div>
                <div style="display: flex; padding-bottom: 18px;width : 450px;">
                    <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Fecha llegada<span style="color: red;"> *</span><br/>
                        <input  type="date" id="llegada" style="width: 100%;" class="form-control"
                                name="txtfechallegada" required="" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e($reserva->fechallegada); ?>" onchange="changeFecha()">
                    </div>
                    <div style=" margin-left : 1%; margin-right : 0; width : 49%;">Fecha salida<span style="color: red;"> *</span><br/>
                        <input type="date" id="salida"  style="width: 100%;" class="form-control"
                               name="txtfechasalida"  required="" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e($reserva->fechasalida); ?>">
                    </div>
                </div>
                <div style="display: flex; padding-bottom: 18px;width : 450px;">
                    <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Numero adultos<span style="color: red;"> *</span><br/>
                        <input type="number" id="adultos" style="width: 100%;" class="form-control" name="txtcantidadadultos"
                               required value="<?php echo e($reserva->adultos); ?>" min="1" pattern="^[0-9]+">
                    </div>
                    <div style=" margin-left : 1%; margin-right : 0; width : 49%;">Numero niños<span style="color: red;"> *</span><br/>
                        <input type="number"  style="width: 100%;" class="form-control" name="txtnumeroninos" id="ninos" required value="<?php echo e($reserva->ninos); ?>"
                               min="0" pattern="^[0-9]+">
                    </div>
                </div>

                <div class="form-group">
                    <label for="exampleFormControlSelect2">Seleccione la habitacion disponible</label>
                    <select name="cuarto" multiple class="form-control" id="cuarto">

                    </select>
                </div>

                <div class="container" style="padding: 1%">
                    <label for="total">Total</label>
                    <input type="text" id="total" name="total" class="form-control" readonly>
                </div>

                <br>

            </form>
        </div>

        <div class=" text-center">
            <input type="submit" class="btn btn-lg btn-success  center-block" name="guardar" id="btnReservacion" >
        </div>
        <br>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="https://momentjs.com/downloads/moment.min.js"></script>
    <script src="<?php echo e(asset('/js/admin/reservacionRapida.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u433255739/domains/villadulcesuenos.com/public_html/hotel/resources/views/editReserva.blade.php ENDPATH**/ ?>