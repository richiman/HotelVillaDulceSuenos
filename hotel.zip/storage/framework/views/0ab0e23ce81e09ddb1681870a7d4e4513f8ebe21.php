<div align="center" style="padding-top: 20%">
    <h1>La pagina no esta activa, Favor de contactar a su administrador</h1>
</div>
<?php /**PATH /home/u433255739/domains/villadulcesuenos.com/public_html/hotel/resources/views/noactivo.blade.php ENDPATH**/ ?>