<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', ['ventana' => "Informacion de la Habitacion",'name'=>'roominfo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="d-flex justify-content-around ">
        <form id="formRegistrar">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" value="<?php echo e($hospedaje->id); ?>" id="cuarto">
            <div style="padding-bottom: 18px;font-size : 24px;" class="text-center"><h1>Habitacion: <?php echo e($cliente->numero); ?></h1>
            
            </div>
            <div style="padding-bottom: 18px;font-size : 24px;" class="text-center"><h4>Porcentaje de ocupacion:</h4>
            
            </div>
            <div style="display: flex; padding-bottom: 18px;width : 450px;">
                <div style=" margin-left : 0; margin-right : 1%; width : 100%;">Nombre Huepesd: <span
                        style="color: red;"> *</span><br/>

                    <input type="text" id="data_2" style="width: 100%;" class="form-control" name="txtnombres" required=""
                           value="<?php echo e($hospedaje->nombre); ?>" readonly>
                </div>

            </div>
            <div style="padding-bottom: 18px;">Num. Tel<span style="color: red;"> *</span><br/>
                <input type="text" id="data_4" style="width : 450px;" class="form-control" name="txtnum"
                       value="<?php echo e($hospedaje->telefono); ?>" required="" readonly>
            </div>

            <div style="display: flex; padding-bottom: 18px;width : 450px;">
                <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Fecha llegada<span
                        style="color: red;"> *</span><br/>
                    <input type="date" id="data_2" style="width: 100%;" class="form-control" name="txtfechallegada"
                           required="" value="<?php echo e($hospedaje->fechallegada); ?>" readonly>
                </div>
                <div style=" margin-left : 1%; margin-right : 0; width : 49%;">Fecha salida<span
                        style="color: red;"> *</span><br/>
                    <input type="date" id="data_3" style="width: 100%;" class="form-control" name="txtfechasalida"
                           required="" value="<?php echo e($hospedaje->fechasalida); ?>" min="<?php echo e(date('Y-m-d')); ?>">
                </div>
            </div>
        </form>

    </div>

    <div class=" text-center">
        <input type="submit" class="btn btn-lg btn-success  center-block" name="registrar" value="Registrar" id="registrar">
    </div>

    <br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/admin/roomInfo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u433255739/domains/villadulcesuenos.com/public_html/hotel/resources/views/roomInfo.blade.php ENDPATH**/ ?>