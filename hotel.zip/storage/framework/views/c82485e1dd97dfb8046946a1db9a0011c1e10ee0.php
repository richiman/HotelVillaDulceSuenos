<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.css"/>

    <link rel="stylesheet" href="https://unpkg.com/multiple-select@1.3.1/dist/multiple-select.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.js"></script>

</head>
<body >
<!--- navbar --->
<!-- aquiincluye el menu---->
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--- navbar --->

<!--- reservacion --->

<div class="d-flex justify-content-around " >
    <form id="formReservacion">
        <?php echo e(csrf_field()); ?>

        <div style="padding-bottom: 18px;font-size : 24px;" class="text-center">Llene los datos del Hospedaje  </div>
        <div style="display: flex; padding-bottom: 18px;width : 450px;">
            <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Nombres<span style="color: red;"> *</span><br/>

                <input type="text" id="data_2"  style="width: 100%;" class="form-control" name="txtnombres" required="" >
            </div>
            <div style=" margin-left : 1%; margin-right : 0; width : 49%;">Apellidos<span style="color: red;"> *</span><br/>
                <input type="text" id="data_3"  style="width: 100%;" class="form-control"  name="txtapellidos" required="" >
            </div>
        </div>
        <div style="padding-bottom: 18px;">Num. Tel<span style="color: red;"> *</span><br/>
            <input type="text" id="data_4" style="width : 450px;" class="form-control" name="txtnum" required="" >
        </div>
        <div style="padding-bottom: 18px;">Correo<span style="color: red;"> *</span><br/>
            <input type="text" id="data_5"  style="width : 450px;" class="form-control" name="txtcorreo" required="" >
        </div>
        <div style="display: flex; padding-bottom: 18px;width : 450px;">
            <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Fecha llegada<span style="color: red;"> *</span><br/>
                <input  type="date" id="llegada" style="width: 100%;" class="form-control"
                        name="txtfechallegada" required="" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(date('Y-m-d')); ?>" onchange="changeFecha()">
            </div>
            <div style=" margin-left : 1%; margin-right : 0; width : 49%;">Fecha salida<span style="color: red;"> *</span><br/>
                <input type="date" id="salida"  style="width: 100%;" class="form-control"
                       name="txtfechasalida" required="" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(date('Y-m-d')); ?>">
            </div>
        </div>
        <div style="display: flex; padding-bottom: 18px;width : 450px;">
            <div style=" margin-left : 0; margin-right : 1%; width : 49%;">Numero adultos<span style="color: red;"> *</span><br/>
                <input type="number" id="adultos" style="width: 100%;" class="form-control" name="txtcantidadadultos" required="" value="0">
            </div>
            <div style=" margin-left : 1%; margin-right : 0; width : 49%;">Numero niños<span style="color: red;"> *</span><br/>
                <input type="number" id="ninos" style="width: 100%;" class="form-control" name="txtnumeroninos" required="" value="0" >
            </div>
        </div>

        <div class="form-group">
            <label for="exampleFormControlSelect2">Seleccione la habitacion disponible</label>
            <select name="cuarto" multiple="multiple" class="form-control" id="cuarto">

            </select>
            <script>

            </script>
        </div>

        <div class="form-group">
            <label>Tipo de Reservacion</label>
            <select name="reco" id="reco" class="form-control">
                <option value="RD">Directa</option>
                <option value="RT">Tripticos y Tarjetas</option>
                <option value="RR">Recomendación</option>
                <option value="RC">Coyote</option>
                <option value="RA">Agencias</option>
                <option value="RI">Internet</option>
                <option value="RV">Revistas</option>
                <option value="RF">Facebook</option>
                <option value="RRA">Radio</option>
                <option value="OTAs">OTAs</option>
            </select>
        </div>


    </form>
</div>

<div class=" text-center">
    <input type="submit" class="btn btn-lg btn-success  center-block" name="guardar" id="btnReservacion">
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/js/bootstrap.min.js" integrity="sha384-vZ2WRJMwsjRMW/8U7i6PWi6AlO1L79snBrmgiDpgIWJ82z8eA5lenwvxbMV1PAh7" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://unpkg.com/multiple-select@1.3.1/dist/multiple-select.min.js"></script>
<script src="<?php echo e(asset('/js/admin/reservacionRapida.js')); ?>"></script>
</body>
</html>


<?php /**PATH /home/u433255739/domains/villadulcesuenos.com/public_html/hotel/resources/views/hospedajeRapido.blade.php ENDPATH**/ ?>