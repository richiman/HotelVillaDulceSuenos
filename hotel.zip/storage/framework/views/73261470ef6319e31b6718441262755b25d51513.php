<section class="content-header">
    <h1>
        <?php echo e($ventana); ?>

    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li class="active"><?php echo e($name); ?></li>
    </ol>
</section>
<?php /**PATH C:\Users\battlestation\Desktop\Sistema Hotel\hotel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>