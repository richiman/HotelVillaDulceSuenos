<section class="content-header">
    <h1>
        {{$ventana}}
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li class="active">{{$name}}</li>
    </ol>
</section>
