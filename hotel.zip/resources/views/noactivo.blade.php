<div align="center" style="padding-top: 20%">
    <h1>La pagina no esta activa, Favor de contactar a su administrador</h1>
</div>
